from pyfame.file_access import get_video_capture, get_video_writer, get_imread, create_output_directory
from pyfame.utils.exceptions import *
from pyfame.utils.checks import *
from pyfame.layer.timing_curves import *
from pyfame.landmark.facial_landmarks import *
from pyfame.layer._layer import Layer
from pyfame.layer._layer_pipeline import LayerPipeline
from pyfame.logging.write_experiment_log import write_experiment_log
from pyfame.landmark.get_landmark_coordinates import get_face_landmarker, get_landmarker_coordinates
import cv2 as cv
import os
import pandas as pd
import numpy as np
from datetime import datetime
from tqdm import tqdm

def _resolve_timing(layer:Layer, video_duration:float):
    onset = 0.0 if layer.onset_t is None else layer.onset_t
    offset = video_duration if layer.offset_t is None else layer.offset_t
    if offset < 0.0:
        offset = video_duration + offset

    if not (0.0 <= onset < offset):
        raise ValueError(f"apply_layers: time_onset must be greater than zero, and less than time_offset for layer {type(layer).__name__}.")
    elif not (onset < offset <= video_duration):
        raise ValueError(f"apply_layers: time_offset must be greater than time_onset, and less than the videos duration for layer {type(layer).__name__}.")

    # Update timing config object
    layer.config = layer.config.model_copy(update={
        "onset_time_msec": onset,
        "offset_time_msec": offset
    })

    # keep layer.self params in sync
    layer.onset_t = onset
    layer.offset_t = offset

def _create_session_directory(output_dir: Path) -> tuple[Path, str]:
    # Get the current sys timestamp for a unique output folder
    # name that will identify the processing session
    timestamp = datetime.now().isoformat(timespec='microseconds')
    timestamp_str = timestamp.replace(":","-")
    timestamp_id = timestamp_str

    session_dir = output_dir / timestamp_id
    counter = 1

    while True:
        try:
            session_dir.mkdir(parents=True, exist_ok=False)
            return (session_dir, timestamp_id)
        except FileExistsError:
            timestamp_id = f"{timestamp_str}_{counter}"
            session_dir = output_dir / timestamp_id
            counter += 1

def apply_layers(file_paths:pd.DataFrame, layers:list[Layer] | Layer, min_face_detection_confidence:float = 0.4, 
                 min_face_presence_confidence:float = 0.7, min_face_tracking_confidence:float = 0.7):
    """ Takes in a list of layer objects, and applies each manipulation layer in sequence frame-by-frame, and file-by-file for each file provided within input_dir.

    Parameters
    ----------
    file_paths: pandas.DataFrame
        A dataframe of path strings returned by make_paths().
    layers: list of Layer
        A list of Layer objects containing the specified layer and its parameters.
    min_face_detection_confidence: float
        A confidence parameter passed to the mediapipe FaceLandmarker instance.
        Controls how confident the detection model needs to be to confirm a face is present in the frame.
    min_face_presence_confidence: float
        A confidence parameter passed to the mediapipe FaceLandmarker instance.
        Controls how confident the landmarker needs to be that the detected face is still present, 
        if not it will attempt to re-detect the face.
    min_face_tracking_confidence: float
        A confidence parameter passed to the mediapipe FaceLandmarker instance. 
        Controls how confident the facial tracking model needs to be for the landmarker to 
        continue using the current mesh layout. If this parameter fails, the landmarker will
        transition back to facial detection.
    
    Returns
    -------
    None
    
    Raises
    ------
    
    OSError
        When expected input/output directories do not exist.
    FileReadError
        Given invalid file paths, or an incompatible video/image container.
    FileWriteError
        When an error occurs attempting to write out an image or video frame.
    UnrecognizedExtensionError
        Given an image or video with an unrecognized container/codec.
    """

    # Validate input params
    check_file_paths(file_paths=file_paths)

    check_type(layers, [list, Layer])
    if isinstance(layers, list):
        check_type(layers, [Layer], iterable=True)

    mp_params = [min_face_detection_confidence, min_face_presence_confidence, min_face_tracking_confidence]
    for p in mp_params:
        check_type(p, [float])
        check_value(p, minimum=0.0, maximum=1.0)

    # Extracting the i/o paths from the file_paths dataframe
    if len(file_paths["Absolute Path"]) == 0:
        raise FileReadError(message="File_paths dataframe is empty, please inspect your working folder to ensure you have populated the raw/ directory.")

    absolute_paths = file_paths["Absolute Path"]
    relative_paths = file_paths["Relative Path"]

    # Determine the root data/ directory from the first file.
    absolute_path = Path(absolute_paths.iloc[0]).resolve()
    relative_path = Path(relative_paths.iloc[0])

    root_directory = absolute_path

    for _ in relative_path.parts[1:]:
        root_directory = root_directory.parent

    # Set up input/output directories.
    input_directory = root_directory / "raw"
    output_directory = root_directory / "processed"

    # Validate the expected PyFAME directory structure.
    if not input_directory.is_dir():
        raise FileReadError(
            message=(
                f"Unable to locate the 'raw' subdirectory under "
                f"'{root_directory}'. Please call make_paths() to set up "
                f"the correct directory structure."
            )
        )

    if not output_directory.is_dir():
        raise FileReadError(
            message=(
                f"Unable to locate the 'processed' subdirectory under "
                f"'{root_directory}'. Please call make_paths() to set up "
                f"the correct directory structure."
            )
        )

    # Create this run's output directory.
    output_directory, timestamp_id = _create_session_directory(output_directory)

    # Initialize the processing pipeline
    pipeline = LayerPipeline()
    if isinstance(layers, list):
        pipeline.add_layers(layers)
    else:
        pipeline.add_layer(layers)

    static_image_mode = False
    log_output = False

    # Iterate over file list
    for i,file in enumerate(
        tqdm(
            absolute_paths, 
            total=len(absolute_paths), 
            desc="Files processed",
            bar_format='[{elapsed}<{remaining}] {n_fmt}/{total_fmt} | {l_bar}{bar} {rate_fmt}{postfix}',
            position=0,
            dynamic_ncols=True
        )
    ):
        
        if not os.path.isfile(file):
            raise FileReadError(file_path=file)
        
        filename, extension = os.path.splitext(os.path.basename(file))
        codec = "mp4v"
        capture = None
        result = None
        cap_duration = 0

        # Saving the absolute output path for writing out later
        dir_file_path = os.path.join(output_directory, f"{filename}{extension}")

        # Using the file extension to sniff video codec or image container for images
        if str.lower(extension) not in {".mp4", ".mov", ".jpg", ".jpeg", ".png", ".bmp"}:
            print(f"Skipping unparseable file {os.path.basename(file)}.")
            continue
        
        elif str.lower(extension) in {".jpg", ".jpeg", ".png", ".bmp"}:
            static_image_mode = True
        
        if not static_image_mode:
            capture = get_video_capture(file)
            # Getting the video duration for weight calculations
            frame_count = capture.get(cv.CAP_PROP_FRAME_COUNT)
            fps = capture.get(cv.CAP_PROP_FPS)
            size = (int(capture.get(3)), int(capture.get(4)))
            result = get_video_writer(dir_file_path, size, codec, frame_rate=fps)

            if fps == 0:
                raise FileReadError(message="Input video fps is zero. File may be corrupt or incorrectly encoded.")
            else:
                # convert to msec
                cap_duration = (float(frame_count)/float(fps))*1000

            for layer in pipeline.layers:
                _resolve_timing(layer, cap_duration)
        else:
            frame_count = 1
        
        # We need to call the faceLandmarker only once per frame, specifically for video running mode.
        # Instantiate a single, top-level faceLandmarker instance that will be passed to layers
        face_landmarker = get_face_landmarker(
            running_mode = "image" if static_image_mode else "video",
            num_faces=1,
            min_face_detection_confidence=min_face_detection_confidence,
            min_face_presence_confidence=min_face_presence_confidence,
            min_face_tracking_confidence=min_face_tracking_confidence,
            output_face_blendshapes=True
        )
        
        # Loop over the current file until completion; (single iteration for static images)
        pb = tqdm(
            total=frame_count, 
            desc="Frames processed",
            bar_format='[{elapsed}<{remaining}] {n_fmt}/{total_fmt} | {l_bar}{bar} {rate_fmt}{postfix}', 
            colour="blue",
            position=1,
            dynamic_ncols=True
        )
        while(True):

            if static_image_mode:
                frame = get_imread(file)
                if frame is None:
                    break
                landmark_coordinates, blendshapes = get_landmarker_coordinates(cv.cvtColor(frame, cv.COLOR_BGR2RGB), face_landmarker, None, static_image_mode, True)
            else:
                success, frame = capture.read()
                if not success:
                    break
                dt = capture.get(cv.CAP_PROP_POS_MSEC)
                landmark_coordinates, blendshapes = get_landmarker_coordinates(cv.cvtColor(frame, cv.COLOR_BGR2RGB), face_landmarker, dt, static_image_mode, True)
            
            pb.update(1)

            if blendshapes is None:
                raise FaceNotFoundError(message="FaceLandmarker failed to identify and return blendshapes.")

            if not static_image_mode:
                # Getting the current video timestamp
                output_frame = pipeline.apply_layers(landmark_coordinates, frame, dt, blendshapes=blendshapes)
                output_frame = output_frame.astype(np.uint8)
                result.write(output_frame)
            else:
                output_frame = pipeline.apply_layers(landmark_coordinates, frame, None, blendshapes=blendshapes)
                output_frame = output_frame.astype(np.uint8)
                success = cv.imwrite(dir_file_path, output_frame)
                if not success:
                    raise FileWriteError()
                
                break
        
        if pb.__getattribute__("n") < frame_count:
            pb.update(frame_count - pb.__getattribute__("n"))
            
        pb.close()

        if not log_output:
            write_experiment_log(layers, timestamp_id, root_directory)
            log_output = True
    
        if not static_image_mode:
            capture.release()
            result.release()

        if isinstance(layers, list):
            for layer in layers:
                layer._reset_state()
        else:
            layers._reset_state()

__all__ = ["apply_layers", "_resolve_timing"]